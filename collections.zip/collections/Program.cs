﻿using System;
using System.Collections.Generic;

namespace collections
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            List<int> first_list=new List<int>();
            int[] first_array={1,2,3,4,5,6,7,8,9};
            string[] second_array={"Tim","Martin", "Nikki", "Sara"};
            bool[] third_array= new bool[10]{true,false,true,true,false,true,true,false,true,false};
            
            for(int i=0; i< 11;i++){

            }

            for (int i=1;i<10;i++){
                first_list.Add(i);
            }
            // Console.WriteLine(first_array[5]);
            // Console.WriteLine(second_array[2]);
            // Console.WriteLine(third_array[2]);
            // multiplication();
            // icecreams();
            user_choice(second_array,icecreams());

        }
            static void multiplication(){   
                int [,]mult=new int[10,10];

                for (int i=0;i<10;i++){
                // Console.WriteLine("index"+i);
                        for(int j=0;j<10;j++){
                            // Console.WriteLine("index y"+j);
                            mult[i,j]=(i+1)*(j+1);
                        }
        
                }
        
                foreach(int num in mult){
                    Console.WriteLine("num"+num);

                }
            }
            static List<string> icecreams(){
                List<string> icecreams=new List<string>();
                icecreams.Add("Chocolate");
                icecreams.Add("Vanilla");
                icecreams.Add("Strawberry");
                icecreams.Add("Coffee");
                icecreams.Add("Peach");
                Console.WriteLine("We have {0} Ice cream flavors",icecreams.Count);
                Console.WriteLine("The third Ice cream flavor is {0}",icecreams[0]); 
                icecreams.RemoveAt(2);
                Console.WriteLine("We have {0} Ice cream flavors",icecreams.Count);
                return icecreams;
            }
            static void user_choice(string[]users,List<string>flavors){
                Dictionary<string,string> choices= new Dictionary<string,string>();
                for (int i=0; i< users.Length;i++){
                    choices.Add(users[i],flavors[i]);
                }
                foreach(var choice in choices){
                    Console.WriteLine("{0} likes {1} flavor",choice.Key,choice.Value);
                }
            }
        

        

    }
}
